"""
슈핏케어 진단 엔진 (core/engine.py)
=====================================
역할: 기성화 추천 우선 → 발볼늘림 보완 로직
     반품율 감소가 최우선 목표
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional
import uuid


# ──────────────────────────────────────────────
# 1. 기성화 제품 카탈로그 (실제 운영시 DB에서 로드)
# ──────────────────────────────────────────────
PRODUCT_CATALOG = {
    "구두": [
        {"id": "dress_slim",  "name": "슬림핏 구두",    "fit": "기본핏",    "width_code": "D",  "toe": "pointed", "notes": "발볼 좁음, 무지외반 비추"},
        {"id": "dress_wide",  "name": "와이드핏 구두",   "fit": "편한핏",    "width_code": "EE", "toe": "round",   "notes": "넓은 발볼 대응"},
        {"id": "dress_extra", "name": "익스트라 구두",   "fit": "아주 편한핏","width_code": "EEE","toe": "round",   "notes": "무지외반·넓은볼 최적"},
    ],
    "로퍼": [
        {"id": "loafer_std",  "name": "스탠다드 로퍼",  "fit": "기본핏",    "width_code": "D",  "toe": "round",   "notes": "기본"},
        {"id": "loafer_wide", "name": "와이드 로퍼",    "fit": "편한핏",    "width_code": "EE", "toe": "round",   "notes": "넓은볼 적합"},
    ],
    "단화": [
        {"id": "flat_basic",  "name": "베이직 단화",    "fit": "기본핏",    "width_code": "D",  "toe": "round",   "notes": "기본"},
        {"id": "flat_wide",   "name": "와이드 단화",    "fit": "편한핏",    "width_code": "EE", "toe": "wide",    "notes": "넓은볼 편안"},
    ],
    "운동화": [
        {"id": "sneaker_std", "name": "스탠다드 운동화", "fit": "기본핏",    "width_code": "D",  "toe": "round",   "notes": "기본"},
        {"id": "sneaker_wide","name": "와이드 운동화",   "fit": "편한핏",    "width_code": "EE", "toe": "round",   "notes": "넓은볼·발등 높음"},
        {"id": "sneaker_xtra","name": "익스트라 운동화", "fit": "아주 편한핏","width_code": "EEE","toe": "round",   "notes": "무지외반·복합 증상"},
    ],
}

# ──────────────────────────────────────────────
# 2. 데이터 클래스 정의
# ──────────────────────────────────────────────
@dataclass
class CustomerInput:
    """고객 입력 원본 (변경 없이 보존 → RAG 원문 데이터)"""
    session_id: str
    preferred_style: str        # "기본핏" | "편한핏" | "아주 편한핏"
    foot_issues: list[str]      # ["넓음", "무지외반", ...]
    hallux_severity: str        # "0" | "1" | "2" | "3"
    instep_severity: str        # "0" | "1" | "2" | "3"
    toe_detail: str             # "0" | "1" | "2"
    design: str                 # "구두" | "로퍼" | ...
    original_size: int          # mm
    fit_experience: str         # "잘 맞음" | "헐떡임" | "꽉 껴서"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class DiagnosisResult:
    """진단 결과 (분석 산출물)"""
    session_id: str
    # --- 기성화 추천 (1순위) ---
    recommended_product_id: str
    recommended_product_name: str
    recommended_fit: str
    recommendation_reason: str
    ready_made_possible: bool   # 기성화만으로 해결 가능 여부
    # --- 사이즈 보정 ---
    original_size: int
    final_size: int
    size_adjusted: bool
    # --- 발볼늘림 (2순위, 보완) ---
    stretch_step: int           # 0~3
    stretch_mm: float
    stretch_reason: str
    additional_works: list[str]
    # --- 상담 여부 ---
    is_consult: bool
    consult_reason: str
    # --- 메타 ---
    design: str
    failure_experience: str
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


# ──────────────────────────────────────────────
# 3. 핵심 진단 엔진
# ──────────────────────────────────────────────
class DiagnosisEngine:
    """
    우선순위:
      1) 기성화 추천 (데이터 기반)
      2) 기성화로 해결 불가한 부분만 발볼늘림으로 보완
      3) 복합·심한 증상은 상담으로 전환
    """

    def run(self, inp: CustomerInput) -> DiagnosisResult:
        issues = set(inp.foot_issues)

        # Step 1. 사이즈 보정 (헐떡임 → -5mm)
        final_size, size_adjusted = self._adjust_size(inp)

        # Step 2. 기성화 추천 (최우선)
        product, fit, reason, ready_made = self._recommend_product(inp, issues)

        # Step 3. 상담 필요 여부 판단
        is_consult, consult_reason = self._check_consult(inp, issues)

        # Step 4. 발볼늘림 보완 결정 (기성화 부족분만)
        stretch_step, stretch_mm, stretch_reason = self._decide_stretch(
            inp, issues, ready_made, is_consult
        )

        # Step 5. 추가 가공
        additional = self._additional_works(inp, issues)

        return DiagnosisResult(
            session_id=inp.session_id,
            recommended_product_id=product["id"],
            recommended_product_name=product["name"],
            recommended_fit=fit,
            recommendation_reason=reason,
            ready_made_possible=ready_made,
            original_size=inp.original_size,
            final_size=final_size,
            size_adjusted=size_adjusted,
            stretch_step=stretch_step,
            stretch_mm=stretch_mm,
            stretch_reason=stretch_reason,
            additional_works=additional,
            is_consult=is_consult,
            consult_reason=consult_reason,
            design=inp.design,
            failure_experience=inp.fit_experience,
        )

    # ── 내부 메서드 ──────────────────────────

    def _adjust_size(self, inp: CustomerInput) -> tuple[int, bool]:
        if "헐떡임" in inp.fit_experience:
            return inp.original_size - 5, True
        return inp.original_size, False

    def _recommend_product(
        self, inp: CustomerInput, issues: set
    ) -> tuple[dict, str, str, bool]:
        catalog = PRODUCT_CATALOG.get(inp.design, [])
        if not catalog:
            return {"id": "unknown", "name": "미등록 디자인"}, inp.preferred_style, "카탈로그 없음", False

        hallux = inp.hallux_severity
        instep = inp.instep_severity

        # 심한 복합증상 → 기성화 한계
        if "무지외반" in issues and hallux == "3":
            # EEE 폭 제품 우선 탐색
            product = self._find_by_width(catalog, "EEE") or catalog[-1]
            return (
                product,
                "아주 편한핏",
                "무지외반 심함: 가장 넓은 폭 기성화 선택, 발볼늘림 추가 필요",
                False,  # 기성화만으로 부족 → 가공 필요
            )

        if "넓음" in issues and "무지외반" in issues:
            product = self._find_by_width(catalog, "EE") or catalog[-1]
            return product, "편한핏", "넓은볼+무지외반: EE 폭 기성화로 1차 해결", True

        if "넓음" in issues:
            product = self._find_by_width(catalog, "EE") or catalog[-1]
            return product, "편한핏", "넓은 발볼: EE 폭 기성화 추천", True

        if "무지외반" in issues:
            product = self._find_by_width(catalog, "EE") or catalog[-1]
            return product, "편한핏", "무지외반: EE 폭 기성화 추천", True

        if "발등 높음" in issues and instep == "3":
            # 발등 심함은 기성화 한계
            product = self._find_by_width(catalog, "EE") or catalog[-1]
            return product, "편한핏", "발등 심함: 기성화 + 상담 필요", False

        # 기본 케이스
        product = self._find_by_fit(catalog, inp.preferred_style) or catalog[0]
        return product, inp.preferred_style, f"선호 스타일 {inp.preferred_style} 기성화 추천", True

    def _find_by_width(self, catalog: list, width_code: str) -> Optional[dict]:
        for p in catalog:
            if p["width_code"] == width_code:
                return p
        return None

    def _find_by_fit(self, catalog: list, fit: str) -> Optional[dict]:
        for p in catalog:
            if p["fit"] == fit:
                return p
        return None

    def _check_consult(self, inp: CustomerInput, issues: set) -> tuple[bool, str]:
        if "무지외반" in issues and inp.hallux_severity == "3":
            return True, "무지외반 심함: 돌출부 형태 직접 확인 필요"
        if "발등 높음" in issues and inp.instep_severity == "3":
            return True, "발등 심함: 발등 높이 직접 측정 필요"
        return False, ""

    def _decide_stretch(
        self,
        inp: CustomerInput,
        issues: set,
        ready_made: bool,
        is_consult: bool,
    ) -> tuple[int, float, str]:
        """
        기성화로 해결 가능하면 가공 최소화.
        기성화 부족분만 가공으로 보완.
        """
        if is_consult:
            return 0, 0.0, "상담 후 결정"

        # 심한 무지외반 → 기성화 부족 → 3단계 가공
        if "무지외반" in issues and inp.hallux_severity == "3":
            return 3, 7.5, "기성화 EEE 폭으로도 부족한 돌출부 핀포인트 보정"

        # 헐떡임으로 사이즈 다운 → 줄어든 볼 공간 보완 (1단계)
        if "헐떡임" in inp.fit_experience and ("넓음" in issues or "무지외반" in issues):
            return 1, 2.5, "사이즈 다운 보상: 줄어든 볼 공간 1단계 보완"

        # 기성화만으로 해결 가능하면 가공 없음
        if ready_made:
            return 0, 0.0, "기성화로 충분히 해결 가능"

        # 중간 케이스 → 2단계
        if "넓음" in issues and "무지외반" in issues:
            return 2, 5.0, "기성화 보완: 2단계 넓힘 추가"

        return 0, 0.0, "가공 불필요"

    def _additional_works(self, inp: CustomerInput, issues: set) -> list[str]:
        works = []
        if "앞코" in issues:
            works.append("발끝 닿음 늘림" if inp.toe_detail == "1" else "앞코 너비 늘림")
        if "발등 높음" in issues and inp.instep_severity in ("1", "2"):
            works.append("발등 높이 늘림")
        return works
