"""
슈핏케어 FastAPI 어댑터 (adapters/api.py)
==========================================
CLI → Web API / 카카오 챗봇으로 전환 시 이 파일만 추가.
ConversationController와 SessionStore는 그대로 재사용.

실행:
    pip install fastapi uvicorn
    uvicorn adapters.api:app --reload
"""

# ──────────────────────────────────────────────
# FastAPI 어댑터 (설치 시 활성화)
# ──────────────────────────────────────────────
try:
    from fastapi import FastAPI, HTTPException
    from pydantic import BaseModel
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

    from core.session import ConversationController, SessionStore
    from core.storage import init_db

    app = FastAPI(title="슈핏케어 API")
    store = SessionStore()
    ctrl  = ConversationController(store=store)
    init_db()

    class MessageRequest(BaseModel):
        session_id: str | None = None
        message:    str
        channel:    str = "web"
        customer_id: str | None = None

    @app.post("/chat")
    def chat(req: MessageRequest):
        """
        단일 엔드포인트 — 채널 무관하게 동일하게 동작.
        카카오: POST /chat  {"session_id": "xxx", "message": "1"}
        웹챗:   POST /chat  {"session_id": null,  "message": "시작"}
        """
        # 세션 로드 or 신규 생성
        session = None
        if req.session_id:
            session = store.load(req.session_id)

        if session is None:
            session = ctrl.new_session(channel=req.channel, customer_id=req.customer_id)
            # 신규 세션 → 첫 안내 반환
            intro = ctrl.get_initial_prompt()
            store.save(session)
            return {"session_id": session.session_id, **intro}

        # 메시지 처리
        result = ctrl.handle_message(session, req.message)
        return {"session_id": session.session_id, **result}

    @app.post("/feedback")
    def feedback(session_id: str, was_returned: bool, reason: str = ""):
        """반품 피드백 수신 — 주문 완료 후 별도 호출"""
        from core.storage import save_return_feedback, update_rag_return_status
        save_return_feedback(session_id, was_returned, reason)
        update_rag_return_status(session_id, was_returned, reason)
        return {"ok": True}

    @app.get("/report")
    def report():
        """반품율 리포트"""
        from core.storage import get_return_rate_report
        return get_return_rate_report()

except ImportError:
    # fastapi 미설치 시 스킵 (CLI 모드에서는 불필요)
    pass


# ──────────────────────────────────────────────
# 카카오 챗봇 어댑터 스켈레톤
# ──────────────────────────────────────────────
"""
카카오 i 오픈빌더 웹훅 형식:

POST /kakao/chat
{
  "userRequest": {
    "user": {"id": "kakao_user_id"},
    "utterance": "2"
  }
}

응답:
{
  "version": "2.0",
  "template": {
    "outputs": [{"simpleText": {"text": "..."}}],
    "quickReplies": [{"label": "1.기본핏", "action": "message", "messageText": "1"}]
  }
}
"""

def kakao_webhook_handler(kakao_payload: dict) -> dict:
    """카카오 페이로드 → ConversationController → 카카오 응답 포맷"""
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from core.session import ConversationController, SessionStore

    _store = SessionStore()
    _ctrl  = ConversationController(store=_store)

    user_id  = kakao_payload["userRequest"]["user"]["id"]
    utterance = kakao_payload["userRequest"]["utterance"]

    # 카카오 user_id를 session_id로 사용 (1:1 매핑)
    session = _store.load(user_id)
    if session is None:
        session = _ctrl.new_session(channel="kakao", customer_id=user_id)
        session.session_id = user_id  # 카카오 user_id = session_id
        result = _ctrl.get_initial_prompt()
    else:
        result = _ctrl.handle_message(session, utterance)

    _store.save(session)

    # 카카오 응답 포맷으로 변환
    quick_replies = [
        {"label": qr, "action": "message", "messageText": qr}
        for qr in result.get("quick_replies", [])
    ]

    return {
        "version": "2.0",
        "template": {
            "outputs": [{"simpleText": {"text": result["text"]}}],
            "quickReplies": quick_replies,
        }
    }
